# Maíz enfermo  > 2024-11-17 3:49pm
https://universe.roboflow.com/deteccion-de-plagas/maiz-enfermo

Provided by a Roboflow user
License: CC BY 4.0

