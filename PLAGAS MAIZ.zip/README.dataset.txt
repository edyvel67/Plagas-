# Plagas 2 > 2024-11-19 11:53am
https://universe.roboflow.com/deteccion-de-plagas/plagas-2

Provided by a Roboflow user
License: CC BY 4.0

