# TEJOCOTE > 2024-10-17 1:41am
https://universe.roboflow.com/deteccion-de-plagas/tejocote

Provided by a Roboflow user
License: CC BY 4.0

